s = input()
f = open("output.txt", "a")
f.write(f"Hi, {s}")
f.close()