l = input().split()
a = int(l[0])
b = int(l[1])
c = int(l[2])
d = int(l[3])

print( (d + b) // (a-c))